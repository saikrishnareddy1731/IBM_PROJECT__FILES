package in.ibm.demo.bean;

public enum AccountType {

	SAVINGS,
	CURRENT,
	CREDIT_CARD,
	LOAN
}
