package in.ibm.bean;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class Person {

	private String name= "Shivam Kumar";
	private int age =22;
	private boolean isProgrammer = true;
	private Address address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public boolean isProgrammer() {
		return isProgrammer;
	}
	public void setProgrammer(boolean isProgrammer) {
		this.isProgrammer = isProgrammer;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", isProgrammer=" + isProgrammer + ", address=" + address
				+ "]";
	}
	
	
	
}
