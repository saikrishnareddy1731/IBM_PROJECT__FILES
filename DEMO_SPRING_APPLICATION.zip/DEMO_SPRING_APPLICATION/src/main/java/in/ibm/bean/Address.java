package in.ibm.bean;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class Address {
	
	private int streetNo =2588;
	private String streetName = "Gandhi";
	private String City ="Karimnagar";
	private String Country ="India";
	
	
//	public int getStreetNo() {
//		return streetNo;
//	}
//	
//	public String getStreetName() {
//		return streetName;
//	}
//	
//	public String getCity() {
//		return City;
//	}
//	
//	public String getCountry() {
//		return Country;
//	}

	@Override
	public String toString() {
		return "Address [streetNo=" + streetNo + ", streetName=" + streetName + ", City=" + City + ", Country="
				+ Country + "]";
	}


}
