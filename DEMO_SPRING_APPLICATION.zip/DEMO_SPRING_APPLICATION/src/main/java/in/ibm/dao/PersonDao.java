package in.ibm.dao;

import in.ibm.bean.Person;

public interface PersonDao {

	public Person getPersonInfo();
}
