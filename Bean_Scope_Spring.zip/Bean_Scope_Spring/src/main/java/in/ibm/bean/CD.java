package in.ibm.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CD {

	private String cdID;
	private String cdTitle;
	private int cdYear;

	public String getCdID() {
		return cdID;
	}

	public void setCdID(String cdID) {
		this.cdID = cdID;
	}

	public String getCdTitle() {
		return cdTitle;
	}

	public void setCdTitle(String cdTitle) {
		this.cdTitle = cdTitle;
	}

	public int getCdYear() {
		return cdYear;
	}

	public void setCdYear(int cdYear) {
		this.cdYear = cdYear;
	}

	public CD() {
		// TODO Auto-generated constructor stub
	}

	public CD(String cdTitle, int cdYear) {
		super();
		this.cdTitle = cdTitle;
		this.cdYear = cdYear;
	}

	public void getDetails() {
		System.out.printf("CD_ID: %s CD_NAME: %s CD YEAR %d\n", getCdID(), getCdTitle(), getCdYear());
	}
	public void init() {
		System.out.println("Init method called------");
	}
	
	public void distory() {
		
		System.out.println("Destory method called -----------");
	}

}
