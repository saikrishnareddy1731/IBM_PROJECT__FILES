package com.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Image {
	private int id;
	private String name;
	private Boolean isAvalaible;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getIsAvalaible() {
		return isAvalaible;
	}
	public void setIsAvalaible(Boolean isAvalaible) {
		this.isAvalaible = isAvalaible;
	}
	public Image(int id, String name, Boolean isAvalaible) {
		super();
		this.id = id;
		this.name = name;
		this.isAvalaible = isAvalaible;
	}
	
	
	

}
